# Animated Continuous Sections with GSAP Observer

A Pen created on CodePen.io. Original URL: [https://codepen.io/nothing4us/pen/abjdNNb](https://codepen.io/nothing4us/pen/abjdNNb).

