#  Responsive Parallax Drag -slider With Transparent Letters | Nothing4us 

A Pen created on CodePen.io. Original URL: [https://codepen.io/nothing4us/pen/LYBYyjB](https://codepen.io/nothing4us/pen/LYBYyjB).

