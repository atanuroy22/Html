# Yeti Hand Pagination | Nothing4us

A Pen created on CodePen.io. Original URL: [https://codepen.io/nothing4us/pen/bGKpxKJ](https://codepen.io/nothing4us/pen/bGKpxKJ).

