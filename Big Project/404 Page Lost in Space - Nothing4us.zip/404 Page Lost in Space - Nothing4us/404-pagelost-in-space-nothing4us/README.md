# 404 Page - Lost In Space | Nothing4us

A Pen created on CodePen.io. Original URL: [https://codepen.io/nothing4us/pen/vYaGXPO](https://codepen.io/nothing4us/pen/vYaGXPO).

